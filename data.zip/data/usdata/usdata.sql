DROP TABLE IF EXISTS usdata;

DROP TABLE IF EXISTS construction;
CREATE TABLE construction (
  state VARCHAR( 64 ),
  companies INT,
  employees INT,
  payroll INT,
  sales INT,
  statepopulation INT
);

LOAD DATA LOCAL INFILE 'construction.csv' INTO TABLE construction FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"';

DROP TABLE IF EXISTS it;
CREATE TABLE it (
  state VARCHAR( 64 ),
  companies INT,
  employees INT,
  payroll INT,
  sales INT,
  statepopulation INT
);

LOAD DATA LOCAL INFILE 'it.csv' INTO TABLE it FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"';

DROP TABLE IF EXISTS realestate;
CREATE TABLE realestate (
  state VARCHAR( 64 ),
  companies INT,
  employees INT,
  payroll INT,
  sales INT,
  statepopulation INT
);

LOAD DATA LOCAL INFILE 'realestate.csv' INTO TABLE realestate FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"';
